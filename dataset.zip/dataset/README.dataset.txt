# Dental2 > 2025-04-09 5:50pm
https://universe.roboflow.com/ino-test/dental2-kvtp2

Provided by a Roboflow user
License: ODbL v1.0

